package com.practical.students.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practical.students.entity.Response;
import com.practical.students.entity.Students;
import com.practical.students.repository.StudentsRepository;

@Service
public class StudentsService {

	@Autowired
	private StudentsRepository studentsRepository;
	
	
	
	public Students saveStudents(Students student) {
		return studentsRepository.save(student);
	}
	
	public List<Response> getStudentInformation(){
		List<Students> studentList=studentsRepository.findAll();
		List<Response> responses=new ArrayList<>();
		studentList.stream().forEach(student->{
			Response response=new Response();
			response.setName(student.getName());
			response.setMaths(student.getMaths());
			response.setPhysics(student.getPhysics());
			response.setChemistry(student.getChemistry());
			response.setTotal(student.getTotal());
			response.setPercentage(student.getPercentage());
			responses.add(response);
		});
		return responses;
	}
	
	public Students updateStudents(Long id, Students updateStudent) {
		Students student=studentsRepository.findById(id).get();
		if(Objects.nonNull(student)) {
			student.setName(updateStudent.getName());
			student.setMaths(updateStudent.getMaths());
			student.setPhysics(updateStudent.getPhysics());
			student.setChemistry(updateStudent.getChemistry());
			
		}
		return studentsRepository.save(student);
	}
	
}
