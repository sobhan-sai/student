package com.practical.students.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.practical.students.entity.Response;
import com.practical.students.entity.Students;
import com.practical.students.service.StudentsService;

@RestController
public class StudentController {

	@Autowired
	StudentsService studentService;
	
	@PostMapping
	public Students saveStudents(@RequestBody Students student) {
		return studentService.saveStudents(student);
	}
	
	@GetMapping
	public List<Response> getAllStudents(){
		return studentService.getStudentInformation();
	}
	
	@PutMapping("/students/{id")
	public Students updateStudents(@PathVariable(value = "id") Long id, @RequestBody Students student) {
		return studentService.updateStudents(id,student);
	}
}
